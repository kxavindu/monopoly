#include "types.h"
#include <stdio.h>

//------------------------------------------------------------SQUARES NAMES ARRAY--------------------------------------------------------------
char SQUARES_NAME[40][50] = {
    "Go",
    "Pettah",
    "Community Development Fund",
    "Maradana",
    "Income Tax",
    "Colombo Fort Railway Station",
    "Bambalapitiya",
    "National Event Card 1",
    "Wellawatta",
    "Mount Lavinia",
    "Jail",
    "Nugegoda",
    "Ceylon Electricity Board",
    "Maharagama",
    "Kottawa",
    "Kandy Railway Station",
    "Negombo",
    "Sri Lanka Insurance",
    "Katunayake",
    "Ja-Ela",
    "Free Parking",
    "Kandy City",
    "National Event Card 2",
    "Peradenya",
    "Katugastota",
    "Galle Railway Station",
    "Galle Fort",
    "Unawatuna",
    "National Water Supply and Drainage Board",
    "Hikkaduwa",
    "Go To Jail",
    "Jaffna Town",
    "Nallur",
    "Ceylinco Insurance",
    "Trincomalee",
    "Jaffna Railway Station",
    "National Event Card 3",
    "Nuwara Eliya",
    "Bank Of Ceylon",
    "Galle Face"};

//------------------------------------------------------------INITIALIZE SQUARES--------------------------------------------------------------
void InitializeSquares(SquareType Square[])
{

    for (int i = 0; i < 40; i++)
    {
        Square[i].SquareID = i;

        Square[i].Group = NONE;

        Square[i].Owner = -1;

        Square[i].PurchasePrice = 0;
        Square[i].BaseRent = 0;

        Square[i].Houses = 0;
        Square[i].Hotel = 0;

        Square[i].Mortgaged = 0;

        Square[i].PropertyAge = 0;
        Square[i].PropertyCondition = 100;
    }

    //---------------------------------------------------------------GO------------------------------------------------------------------

    Square[GO].GroupType = GO_SQUARE;

    //-----------------------------------------------------------Properties---------------------------------------------------------------

    Square[Pettah].GroupType = PROPERTY;
    Square[Pettah].Group = BROWN;
    Square[Pettah].PurchasePrice = 1500;
    Square[Pettah].BaseRent = 100;

    Square[Maradana].GroupType = PROPERTY;
    Square[Maradana].Group = BROWN;
    Square[Maradana].PurchasePrice = 1800;
    Square[Maradana].BaseRent = 120;

    Square[Bambalapitiya].GroupType = PROPERTY;
    Square[Bambalapitiya].Group = LIGHT_BLUE;
    Square[Bambalapitiya].PurchasePrice = 2500;
    Square[Bambalapitiya].BaseRent = 180;

    Square[Wellawatta].GroupType = PROPERTY;
    Square[Wellawatta].Group = LIGHT_BLUE;
    Square[Wellawatta].PurchasePrice = 2700;
    Square[Wellawatta].BaseRent = 200;

    Square[MountLavinia].GroupType = PROPERTY;
    Square[MountLavinia].Group = LIGHT_BLUE;
    Square[MountLavinia].PurchasePrice = 3000;
    Square[MountLavinia].BaseRent = 220;

    Square[Nugegoda].GroupType = PROPERTY;
    Square[Nugegoda].Group = PINK;
    Square[Nugegoda].PurchasePrice = 3500;
    Square[Nugegoda].BaseRent = 260;

    Square[Maharagama].GroupType = PROPERTY;
    Square[Maharagama].Group = PINK;
    Square[Maharagama].PurchasePrice = 3800;
    Square[Maharagama].BaseRent = 280;

    Square[Kottawa].GroupType = PROPERTY;
    Square[Kottawa].Group = PINK;
    Square[Kottawa].PurchasePrice = 4000;
    Square[Kottawa].BaseRent = 300;

    Square[Negombo].GroupType = PROPERTY;
    Square[Negombo].Group = ORANGE;
    Square[Negombo].PurchasePrice = 4500;
    Square[Negombo].BaseRent = 350;

    Square[Katunayake].GroupType = PROPERTY;
    Square[Katunayake].Group = ORANGE;
    Square[Katunayake].PurchasePrice = 4700;
    Square[Katunayake].BaseRent = 370;

    Square[JaEla].GroupType = PROPERTY;
    Square[JaEla].Group = ORANGE;
    Square[JaEla].PurchasePrice = 5000;
    Square[JaEla].BaseRent = 400;

    Square[KandyCity].GroupType = PROPERTY;
    Square[KandyCity].Group = RED;
    Square[KandyCity].PurchasePrice = 5500;
    Square[KandyCity].BaseRent = 450;

    Square[Peradenya].GroupType = PROPERTY;
    Square[Peradenya].Group = RED;
    Square[Peradenya].PurchasePrice = 5800;
    Square[Peradenya].BaseRent = 480;

    Square[Katugastota].GroupType = PROPERTY;
    Square[Katugastota].Group = RED;
    Square[Katugastota].PurchasePrice = 6000;
    Square[Katugastota].BaseRent = 500;

    Square[Gallefort].GroupType = PROPERTY;
    Square[Gallefort].Group = YELLOW;
    Square[Gallefort].PurchasePrice = 6500;
    Square[Gallefort].BaseRent = 600;

    Square[Unawatuna].GroupType = PROPERTY;
    Square[Unawatuna].Group = YELLOW;
    Square[Unawatuna].PurchasePrice = 6800;
    Square[Unawatuna].BaseRent = 620;

    Square[Hikkaduwa].GroupType = PROPERTY;
    Square[Hikkaduwa].Group = YELLOW;
    Square[Hikkaduwa].PurchasePrice = 7000;
    Square[Hikkaduwa].BaseRent = 650;

    Square[JaffnaTown].GroupType = PROPERTY;
    Square[JaffnaTown].Group = GREEN;
    Square[JaffnaTown].PurchasePrice = 8000;
    Square[JaffnaTown].BaseRent = 750;

    Square[Nallur].GroupType = PROPERTY;
    Square[Nallur].Group = GREEN;
    Square[Nallur].PurchasePrice = 8300;
    Square[Nallur].BaseRent = 780;

    Square[Trincomalee].GroupType = PROPERTY;
    Square[Trincomalee].Group = GREEN;
    Square[Trincomalee].PurchasePrice = 8500;
    Square[Trincomalee].BaseRent = 800;

    Square[NuwaraEliya].GroupType = PROPERTY;
    Square[NuwaraEliya].Group = DARK_BLUE;
    Square[NuwaraEliya].PurchasePrice = 10000;
    Square[NuwaraEliya].BaseRent = 1000;

    Square[GalleFace].GroupType = PROPERTY;
    Square[GalleFace].Group = DARK_BLUE;
    Square[GalleFace].PurchasePrice = 12000;
    Square[GalleFace].BaseRent = 1200;

    //--------------------------------------------------------------Railway Stations----------------------------------------------------------------------

    Square[FortRailwayStation].GroupType = RAILWAY;
    Square[FortRailwayStation].PurchasePrice = 2000;

    Square[KandyRailwayStation].GroupType = RAILWAY;
    Square[KandyRailwayStation].PurchasePrice = 2000; // change when sir gives the price

    Square[GalleRailwayStation].GroupType = RAILWAY;
    Square[GalleRailwayStation].PurchasePrice = 2000;

    Square[JaffnaRailwayStation].GroupType = RAILWAY;
    Square[JaffnaRailwayStation].PurchasePrice = 2000;

    //----------------------------------------------------------------Utilities----------------------------------------------------------------------

    Square[NationalWaterSupplyAndDrainageBoard].GroupType = UTILITY;
    Square[NationalWaterSupplyAndDrainageBoard].PurchasePrice = 1500; // change when sir gives the price

    Square[CeylonElectricityBoard].GroupType = UTILITY;
    Square[CeylonElectricityBoard].PurchasePrice = 1500;

    //-------------------------------------------------------------------Taxes----------------------------------------------------------------------

    Square[IncomeTax].GroupType = TAX;

    //--------------------------------------------------------------Jail/ GO TO JAIL----------------------------------------------------------------------
    Square[Jail].GroupType = JAIL;
    Square[GoToJail].GroupType = GO_TO_JAIL;

    //----------------------------------------------------------------Free Parking----------------------------------------------------------------------
    Square[FreeParking].GroupType = FREE_PARKING;

    //--------------------------------------------------------------National Event Cards----------------------------------------------------------------------
    Square[NationalEventCard1].GroupType = NATIONAL_EVENT;
    Square[NationalEventCard2].GroupType = NATIONAL_EVENT;
    Square[NationalEventCard3].GroupType = NATIONAL_EVENT;

    //-----------------------------------------------------------------Community Fund----------------------------------------------------------------------

    Square[CommunityDevelopmentFund].GroupType = COMMUNITY_FUND;

    //--------------------------------------------------------------------Insurance----------------------------------------------------------------------

    Square[SriLankaInsurance].GroupType = INSURANCE;
    Square[CeylincoInsurance].GroupType = INSURANCE;

    //----------------------------------------------------------------------Bank----------------------------------------------------------------------

    Square[BankOfCeylon].GroupType = BANK;
}

//------------------------------------------------------------PROCESS SQUARE--------------------------------------------------------------
void ProcessSquare(PlayerType Player[],SquareType Square[], int CurrentPlayer)
{
    switch (Square[Player[CurrentPlayer].Position].GroupType)
    {

    case PROPERTY:
       // HandleProperty(Player, CurrentPlayer);
        break;

    case RAILWAY:
        //HandleRailway(Player, CurrentPlayer);
        break;

    case UTILITY:
        //HandleUtility(Player, CurrentPlayer);
        break;

    case TAX:
       // HandleTax(Player, CurrentPlayer);
        break;

    case JAIL:
       // HandleJail(Player, CurrentPlayer);
        break;

    case GO_TO_JAIL:
       HandleGoToJail(Player, CurrentPlayer);
        break;

    case FREE_PARKING:
        //HandleFreeParking(Player, CurrentPlayer);
        break;

    case NATIONAL_EVENT:
        //HandleNationalEvent(Player, CurrentPlayer);
        break;

    case COMMUNITY_FUND:
        //HandleCommunityFund(Player, CurrentPlayer);
        break;

    case INSURANCE:
       // HandleInsurance(Player, CurrentPlayer);
        break;

    case BANK:
       // HandleBank(Player, CurrentPlayer);
        break;

    case GO_SQUARE:
        break;


    }
}


//-----------------------------------------------------------HANDLING SQUARES----------------------------------------------------------------
void HandleProperty(){};

void HandleRailway(){};

void HandleUtility(){};

void HandleJail(){

    
};

void HandleGoToJail(PlayerType Player [] , int CurrentPlayer){
      Player[CurrentPlayer].Position = Jail;
      Player[CurrentPlayer].InJail = YES;
      Player[CurrentPlayer].JailTurns = 0;

};

void HandleFreeParking(){};


