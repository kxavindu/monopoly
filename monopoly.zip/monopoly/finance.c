//-------------------------------------------------------------HANDLING SQUARES--------------------------------------------------------------

void HandleTax(){};
void HandleBank(){};
void HandleInsurance(){};