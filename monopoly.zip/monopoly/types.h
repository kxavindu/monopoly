#ifndef TYPES_H
#define TYPES_H
#define MAX_ROUND 5
#define PLAYERS 4
#define SQUARES 40
#define GO_MONEY 2000
#define YES 1
#define NO 0


//------------------------------------------------------------ENUMS--------------------------------------------------------------
typedef enum {
    GO,
    Pettah,
    CommunityDevelopmentFund,
    Maradana,
    IncomeTax,
    FortRailwayStation,
    Bambalapitiya,
    NationalEventCard1,
    Wellawatta,
    MountLavinia,
    Jail,
    Nugegoda,
    CeylonElectricityBoard,
    Maharagama,
    Kottawa,
    KandyRailwayStation,
    Negombo,
    SriLankaInsurance,
    Katunayake,
    JaEla,
    FreeParking,
    KandyCity,
    NationalEventCard2,
    Peradenya,
    Katugastota,
    GalleRailwayStation,
    Gallefort,
    Unawatuna,
    NationalWaterSupplyAndDrainageBoard,
    Hikkaduwa,
    GoToJail,
    JaffnaTown,
    Nallur,
    CeylincoInsurance,
    Trincomalee,
    JaffnaRailwayStation,
    NationalEventCard3,
    NuwaraEliya,
    BankOfCeylon,
    GalleFace


} SQ;



typedef enum {
    AggressiveInvester,
    ConservativeBanker,
    RiskTaker,
    OppertunisticTrader
} PlayerName;



typedef enum
{
    GO_SQUARE,
    PROPERTY,
    RAILWAY,
    UTILITY,
    TAX,
    JAIL,
    GO_TO_JAIL,
    FREE_PARKING,
    NATIONAL_EVENT,
    COMMUNITY_FUND,
    INSURANCE,
    BANK
} SquareGroupType;


typedef enum
{
    NONE,
    BROWN,
    LIGHT_BLUE,
    PINK,
    ORANGE,
    RED,
    YELLOW,
    GREEN,
    DARK_BLUE
} PropertyGroup;





//------------------------------------------------------------STRUCTURES--------------------------------------------------------------
typedef struct
{
    // Player Information
    int PlayerID;
    
    // Board
    int Position;
    int Tie; //if tie 1 , else 0
    int CurrentDiceRoll;
    int PlayerRound ;


    // Money
    int Cash;
    int NetWorth;

    // Status
    int Bankrupt;      // 0 = No, 1 = Yes
    int InJail;        // 0 = No, 1 = Yes
    int JailTurns;

    // Loans
    int LoanAmount;
    int LoanInterest;
    int LoanRounds;
    // Insurance
    int InsuranceType;     // 0=None,1=Basic,2=Comprehensive,3=Business
    int InsuranceRounds;

    //owns
    int RailwayStationsOwned;
    int UtilitiesOwned;

} PlayerType;


typedef struct
{
    SQ SquareID;

    SquareGroupType GroupType;
    PropertyGroup Group;

    // Property Information
    int Owner;             // -1 = Unowned
    int PurchasePrice;
    int BaseRent;

    // Buildings
    int Houses;
    int Hotel;

    // Mortgage
    int Mortgaged;

    // Assignment Features
    int PropertyAge;
    int PropertyCondition;

}SquareType;

//------------------------------------------------------------FUNCTION PROTOTYPES--------------------------------------------------------------

//--------------------GAME--------------------
int RollDice();  
void GameStart();
void GameRoundCal(PlayerType Player[], int *GameRound, int CurrentPlayer);












//board 
extern char SQUARES_NAME[40][50];





//players

extern char PLAYER_NAME[4][50];












void  InitializePlayers(PlayerType player[], int PlayerSequence[]);
void InitializeSquares(SquareType Square[]);
void MovePlayer(PlayerType Player[],SquareType Square[],int *GameRound) ;


void ProcessSquare(PlayerType Player[], SquareType Square[],int CurrentPlayer) ;
void HandleGoToJail(PlayerType Player [] , int CurrentPlayer);
int ShouldPayJailFine(PlayerType Player[], int CurrentPlayer);


#endif 
