#include <stdio.h>
#include <stdlib.h>   
#include <time.h>
#include "types.h"  


int main (){
  srand(200); 
  GameStart();
  
  
  
}