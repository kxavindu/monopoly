#include <stdio.h>
#include "types.h"

/*

"Aggressive Invester" player id = 0,
"Conservative Banker" player id = 1,
"Risk Taker" player id = 2,
"Oppertunistic Trader"* player id = 3/

*/

//------------------------------------------------------------PLAYER NAMES ARRAY--------------------------------------------------------------
char PLAYER_NAME[4][50] = {
    "Aggressive Invester",
    "Conservative Banker",
    "Risk Taker",
    "Oppertunistic Trader"};

//------------------------------------------------------------INITIALIZE PLAYERS--------------------------------------------------------------
void InitializePlayers(PlayerType Player[], int PlayerSequence[])
{

    for (int i = 0; i < PLAYERS; i++)
    {
        Player[i].PlayerID = PlayerSequence[i];
        Player[i].Position = 0;
        Player[i].Cash = 30000;
        Player[i].PlayerRound = 1;
        Player[i].Bankrupt = 0;
        Player[i].InJail = 0;
        Player[i].JailTurns = 0;
        printf("%d\n", Player[i].PlayerID);
    }
}

//------------------------------------------------------------MOVE PLAYER--------------------------------------------------------------
void MovePlayer(PlayerType Player[], SquareType Square[], int *GameRound)
{

    for (int i = 0; i < PLAYERS; i++)
    {

        int FirstRoll = RollDice();
        int SecondRoll = RollDice();

        //------checking double roll-----

        if (FirstRoll == SecondRoll)
        {
            Player[i].Tie = YES;
        }
        else
        {
            Player[i].Tie = NO;
        }


        //------in jail check ------
        if (Player[i].InJail == YES)
        {
            if (Player[i].JailTurns >= 3)
            {

                Player[i].InJail = NO;
                Player[i].JailTurns = 0;
            }
            else if (ShouldPayJailFine(Player, i))
            {
                Player[i].InJail = NO;
                Player[i].JailTurns = 0;
                Player[i].Cash -= 300;
            }
            else if (Player[i].Tie)
            {

                Player[i].InJail = NO;
                Player[i].JailTurns = 0;
            }
            else
            {
                Player[i].JailTurns += 1;
                continue;
            }
        }

        //------move players-----------------
        Player[i].Position += (FirstRoll + SecondRoll);
        Player[i].CurrentDiceRoll = FirstRoll + SecondRoll;

        if (Player[i].Position >= 40)
        {
            Player[i].PlayerRound += 1;
            Player[i].Position %= 40;
            Player[i].Cash += GO_MONEY;

            GameRoundCal(Player, GameRound, i);
        }

        ProcessSquare(Player, Square, i);

        printf("%s in %s\n", PLAYER_NAME[Player[i].PlayerID], SQUARES_NAME[Player[i].Position]);
    }
}

//------------------------------------------------------------DECISIONS (start with should) ---------------------------------------------------------------

//----------JAIL FINE-------------
int ShouldPayJailFine(PlayerType Player[], int CurrentPlayer)
{
    switch (Player[CurrentPlayer].PlayerID)
    {
    case AggressiveInvester:
        if (Player[CurrentPlayer].Cash >= 300)
        {
            return YES;
        }
        else
        {
            return NO;
        }

    case OppertunisticTrader:
        if (Player[CurrentPlayer].Cash > 20000)
        {
            return YES;
        }
        else
        {
            return NO;
        }

    default:
        return NO;
    }
}
