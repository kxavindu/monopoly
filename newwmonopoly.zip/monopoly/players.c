#include <stdio.h>
#include "types.h"

/*

"Aggressive Invester" player id = 0,
"Conservative Banker" player id = 1,
"Risk Taker" player id = 2,
"Oppertunistic Trader"* player id = 3/

*/

//------------------------------------------------------------PLAYER NAMES ARRAY--------------------------------------------------------------
char PLAYER_NAME[4][50] = {
    "Aggressive Invester",
    "Conservative Banker",
    "Risk Taker",
    "Oppertunistic Trader"};

//------------------------------------------------------------INITIALIZE PLAYERS--------------------------------------------------------------
void InitializePlayers(PlayerType Player[], int PlayerSequence[])
{

    for (int i = 0; i < PLAYERS; i++)
    {
        Player[i].PlayerID = PlayerSequence[i];
        Player[i].Position = 0;
        Player[i].Cash = 30000;
        Player[i].PlayerRound = 1;
        Player[i].Bankrupt = 0;
        Player[i].InJail = 0;
        Player[i].JailTurns = 0;
        Player[i].PropertiesOwned = 0;
        Player[i].HotelsOwned = 0;
        Player[i].RailwayStationsOwned = 0;
        Player[i].UtilitiesOwned = 0;
        Player[i].LoanAmount = 0;
        Player[i].LoanInterest = 0;
        Player[i].LoanRounds = 0;
        Player[i].NetWorth = 0;
        // printf("%d\n", Player[i].PlayerID);
    }
}

//------------------------------------------------------------MOVE PLAYER--------------------------------------------------------------
void MovePlayer(PlayerType Player[], SquareType Square[], int *GameRound)
{

    for (int i = 0; i < PLAYERS; i++)
    {
        if (*GameRound > MAX_ROUND)
        {
            break;
        }

        //------in jail check ------
        if (Player[i].InJail == YES)
        {
            if (Player[i].JailTurns >= 3)
            {

                Player[i].InJail = NO;
                Player[i].JailTurns = 0;

                if (Player[i].PlayerRound < *GameRound)
                {
                    Player[i].PlayerRound = *GameRound;
                }

                printf("\n%s released from jail by staying three rounds.", PLAYER_NAME[Player[i].PlayerID]);
            }
            else if (ShouldPayJailFine(Player, i))
            {
                Player[i].InJail = NO;
                Player[i].JailTurns = 0;
                Player[i].Cash -= 300;

                if (Player[i].PlayerRound < *GameRound)
                {
                    Player[i].PlayerRound = *GameRound;
                }

                printf("\n%s released from jail by paying fine.", PLAYER_NAME[Player[i].PlayerID]);
            }
        }

        int FirstRoll = RollDice();
        int SecondRoll = RollDice();

        //------checking double roll-----

        if (FirstRoll == SecondRoll)
        {
            Player[i].Tie = YES;
        }
        else
        {
            Player[i].Tie = NO;
        }

        printf("\n%s rolled %d+%d = %d.", PLAYER_NAME[Player[i].PlayerID], FirstRoll, SecondRoll, FirstRoll + SecondRoll);

        if (Player[i].InJail)
        {

            if (Player[i].Tie)
            {

                Player[i].InJail = NO;
                Player[i].JailTurns = 0;

                if (Player[i].PlayerRound < *GameRound)
                {
                    Player[i].PlayerRound = *GameRound;
                }

                printf("\n%s released from jail by rolling doubles.", PLAYER_NAME[Player[i].PlayerID]);
            }
            else
            {
                Player[i].JailTurns += 1;
                printf("\n%s stays on jail (%d/3).\n", PLAYER_NAME[Player[i].PlayerID], Player[i].JailTurns);
                continue;
            }
        }

        //------move players-----------------

        int OldPosition = Player[i].Position;
        Player[i].Position += (FirstRoll + SecondRoll);
        Player[i].CurrentDiceRoll = FirstRoll + SecondRoll;

        int NewPosition = Player[i].Position;

        if (NewPosition >= SQUARES)
        {
            NewPosition %= SQUARES;
        }

        printf("\n%s moves from Square %d to Square %d.", PLAYER_NAME[Player[i].PlayerID], OldPosition, NewPosition);
        printf("\n%s landed on %s.", PLAYER_NAME[Player[i].PlayerID], SQUARES_NAME[NewPosition]);

        /*if (NewPosition == GoToJail)
        {
            printf("\n%s send to jail.", PLAYER_NAME[Player[i].PlayerID]);
        } */

        if (Player[i].Position >= SQUARES)
        {
            Player[i].PlayerRound += 1;
            Player[i].Position %= SQUARES;
            Player[i].Cash += GO_MONEY;

            printf("\n\n%s passed GO.", PLAYER_NAME[Player[i].PlayerID]);
            printf("\nCollected LKR 2,000.");
            printf("\nCurrent Balance : LKR %d\n", Player[i].Cash);

            GameRoundCal(Player, GameRound, i);
        }

        ProcessSquare(Player, Square, i);
        printf("\n");
    }
}

//------------------------------------------------------------DECISIONS (start with should) ---------------------------------------------------------------

//----------JAIL FINE-------------
int ShouldPayJailFine(PlayerType Player[], int CurrentPlayer)

{
    switch (Player[CurrentPlayer].PlayerID)
    {
    case AggressiveInvester:
        if (Player[CurrentPlayer].Cash >= 300)
        {
            return YES;
        }
        else
        {
            return NO;
        }

    case OppertunisticTrader:
        if (Player[CurrentPlayer].Cash > 20000)
        {
            return YES;
        }
        else
        {
            return NO;
        }

    default:
        return NO;
    }
}

//---------BUY PROPERTY----------
int ShouldBuyProperty(PlayerType Player[], SquareType Square[], int CurrentPlayer)

{

    switch (Player[CurrentPlayer].PlayerID)
    {
    case AggressiveInvester:
        if (Player[CurrentPlayer].Cash - Square[Player[CurrentPlayer].Position].PurchasePrice >= MIN_RENT_RESERVE) // change min rent reserve later
            return YES;
        else
            return NO;
        break;

    case ConservativeBanker:

        // Buy only if at least 50% of current cash remains.x
        if ((Player[CurrentPlayer].Cash - Square[Player[CurrentPlayer].Position].PurchasePrice) >= (Player[CurrentPlayer].Cash / 2))
        {
            return YES;
        }
        return NO;
        break;

    case RiskTaker:
        if ((Player[CurrentPlayer].Cash >= Square[Player[CurrentPlayer].Position].PurchasePrice))
        {
            return YES;
        }
        return NO;
        break;

    case OppertunisticTrader:
        /*
               TODO

               Buy only when projected appreciation
               exceeds construction costs.

               After implementing:
                   - Inflation
                   - Market Boom / Decline
                   - Regional Development
                   - Government Regulations

               replace this with the proper calculation.
           */

        return NO;
        break;
    }
    return NO;
}

//--------Buy Railway----------

int ShouldBuyRailway(PlayerType Player[], SquareType Square[], int CurrentPlayer)
{

    switch (Player[CurrentPlayer].PlayerID)
    {
    case AggressiveInvester:
        if (1)
        {
            return YES;
        }
        return NO;
        break;

    case ConservativeBanker:

        if (0)
        {
            return YES;
        }
        return NO;
        break;

    case RiskTaker:
        if (1)
        {
            return YES;
        }
        return NO;
        break;

    case OppertunisticTrader:
        if (0)
        {
            return YES;
        }
        return NO;
        break;
    }
    return NO;
}

//-----Buy Utillity----------

int ShouldBuyUtility(PlayerType Player[], SquareType Square[], int CurrentPlayer)
{
    switch (Player[CurrentPlayer].PlayerID)
    {
    case AggressiveInvester:
        if (0)
        {
            return YES;
        }
        return NO;
        break;

    case ConservativeBanker:

        if (1)
        {
            return YES;
        }
        return NO;
        break;

    case RiskTaker:
        if (0)
        {
            return YES;
        }
        return NO;
        break;

    case OppertunisticTrader:
        if (1)
        {
            return YES;
        }
        return NO;
        break;
    }
    return NO;
}

int ShouldBid(PlayerType Player[], SquareType Square[], int CurrentPlayer, int CurrentBid)
{
    int PropertyID = Player[CurrentPlayer].Position;

    switch (Player[CurrentPlayer].PlayerID)
    {
    case AggressiveInvester:

        if (Player[CurrentPlayer].Cash >= CurrentBid &&
            CurrentBid <= (Square[PropertyID].PurchasePrice * 120) / 100)
        {
            return YES;
        }
        return NO;

    case ConservativeBanker:

        if (Player[CurrentPlayer].Cash >= CurrentBid &&
            CurrentBid <= (Square[PropertyID].PurchasePrice * 120) / 100)
        {
            return YES;
        }
        return NO;

    case RiskTaker:

        if (Player[CurrentPlayer].Cash >= CurrentBid &&
            CurrentBid <= (Square[PropertyID].PurchasePrice * 120) / 100)
        {
            return YES;
        }
        return NO;

    case OppertunisticTrader:

        if (Player[CurrentPlayer].Cash >= CurrentBid &&
            CurrentBid <= (Square[PropertyID].PurchasePrice * 120) / 100)
        {
            return YES;
        }
        return NO;
    }

    return NO;
}