#include <stdio.h>
#include "types.h"

//-------------------------------------------------------------HANDLING SQUARES--------------------------------------------------------------

void HandleTax() {};
void HandleBank() {};
void HandleInsurance() {};

//------------------------------------------------------------BUY PRPERTY-------------------------
void BuyProperty(PlayerType Player[], SquareType Square[], int CurrentPlayer)
{

    int PropertyID = Player[CurrentPlayer].Position;
    Player[CurrentPlayer].Cash -= Square[PropertyID].PurchasePrice;
    Square[PropertyID].Owner = CurrentPlayer;
    Player[CurrentPlayer].PropertiesOwned++;

    printf("\n%s purchased %s for LKR %d.", PLAYER_NAME[Player[CurrentPlayer].PlayerID], SQUARES_NAME[PropertyID], Square[PropertyID].PurchasePrice);
    // printf("\nCurrent Balance : LKR %d\n", Player[CurrentPlayer].Cash);
}

//--------------------------------------------------------RENT PROPERTY-----------------------------
void RentProperty(PlayerType Player[], SquareType Square[], int CurrentPlayer)
{

    int PropertyID = Player[CurrentPlayer].Position;
    int PropertyOwner = Square[PropertyID].Owner;

    Player[CurrentPlayer].Cash -= Square[PropertyID].CurrentRent;
    Player[PropertyOwner].Cash += Square[PropertyID].CurrentRent;
    printf("\n%s paid LKR %d to %s.", PLAYER_NAME[Player[CurrentPlayer].PlayerID], Square[PropertyID].CurrentRent, PLAYER_NAME[Player[PropertyOwner].PlayerID]);
}

//--------------------------------------------------BUY RAILWAY-----------------------------------------
void BuyRailway(PlayerType Player[], SquareType Square[], int CurrentPlayer)
{

    int PropertyID = Player[CurrentPlayer].Position;
    Player[CurrentPlayer].Cash -= Square[PropertyID].PurchasePrice;
    Square[PropertyID].Owner = CurrentPlayer;
    Player[CurrentPlayer].RailwayStationsOwned++;

    printf("\n%s purchased %s for LKR %d.", PLAYER_NAME[Player[CurrentPlayer].PlayerID], SQUARES_NAME[PropertyID], Square[PropertyID].PurchasePrice);
}

//-------------------------------------------------RENT RAILWAY-----------------------------------------

void RentRailway(PlayerType Player[], SquareType Square[], int CurrentPlayer)

{
    int Rent = 0;
    int PropertyID = Player[CurrentPlayer].Position;
    int PropertyOwner = Square[PropertyID].Owner;
    int RailWaysOwned = Player[PropertyOwner].RailwayStationsOwned; // add railway station owner !!!!!!

    switch (RailWaysOwned)
    {
    case 1:
        Rent = 250;
        break;
    case 2:
        Rent = 500;
        break;
    case 3:
        Rent = 1000;
        break;
    case 4:
        Rent = 2000;
        break;

    default:
        break;
    }

    Player[CurrentPlayer].Cash -= Rent;
    Player[PropertyOwner].Cash += Rent;
    printf("\n%s paid LKR %d rent to %s.", PLAYER_NAME[Player[CurrentPlayer].PlayerID], Rent, PLAYER_NAME[Player[PropertyOwner].PlayerID]);
}

//-------------------------------------------------BUY UTILITY---------------------------------------

void BuyUtility(PlayerType Player[], SquareType Square[], int CurrentPlayer)
{
    int UtilityID = Player[CurrentPlayer].Position;

    Player[CurrentPlayer].Cash -= Square[UtilityID].PurchasePrice;
    Square[UtilityID].Owner = CurrentPlayer;
    Player[CurrentPlayer].UtilitiesOwned++;

    printf("\n%s purchased %s for LKR %d.", PLAYER_NAME[Player[CurrentPlayer].PlayerID], SQUARES_NAME[UtilityID], Square[UtilityID].PurchasePrice);
}

void RentUtility(PlayerType Player[], SquareType Square[], int CurrentPlayer)
{
    int Rent = 0;
    int Diece = Player[CurrentPlayer].CurrentDiceRoll;
    int UtilityID = Player[CurrentPlayer].Position;
    int UtilityOwner = Square[UtilityID].Owner;
    int UtilitiesOwned = Player[UtilityOwner].UtilitiesOwned; // add railway station owner !!!!!!

    switch (UtilitiesOwned)
    {
    case 1:
        Rent = Diece * 4;
        break;
    case 2:
        Rent = Diece * 10;
        break;
    default:
        break;
    }

    Player[CurrentPlayer].Cash -= Rent;
    Player[UtilityOwner].Cash += Rent;
    printf("\n%s paid LKR %d rent to %s.", PLAYER_NAME[Player[CurrentPlayer].PlayerID], Rent, PLAYER_NAME[Player[UtilityOwner].PlayerID]);
}
//-----------------------------------------------START OCTION---------------------------------------
void StartAuction(PlayerType Player[], SquareType Square[], int CurrentPlayer)
{
    int PropertyID = Player[CurrentPlayer].Position;
    printf("\n\n--------------- Auction Started --------------------");
    //printf("\nAuction Started.");
    printf("\n\nProperty :");
    printf("\n%s", SQUARES_NAME[PropertyID]);
    printf("\n\nOpening Bid :");
    printf("\nLKR %d\n", (Square[PropertyID].PurchasePrice) / 2);

    int ActivePlayers = 0;
    int PlayerWithdrawn[PLAYERS] = {0};
    int CurrentBid = (Square[PropertyID].PurchasePrice) / 2;
    int Winner = -1;

    for (int i = 0; i < PLAYERS; i++)
    {
        if (Player[i].Bankrupt == NO)
            ActivePlayers++;
    }

    while (ActivePlayers > 1)
    {
        for (int i = 0; i < PLAYERS; i++)
        {
            if (Player[i].Bankrupt == YES)
                continue;

            if (PlayerWithdrawn[i] == YES)
                continue;

            if (ShouldBid(Player, Square, i, CurrentBid))
            {

                Winner = i;

                printf("\n%s bids LKR %d.", PLAYER_NAME[Player[i].PlayerID], CurrentBid);
                CurrentBid += 250;
            }
            else
            {
                PlayerWithdrawn[i] = YES;
                ActivePlayers--;

                printf("\n%s withdraws.", PLAYER_NAME[Player[i].PlayerID]);

               if (ActivePlayers <= 1)
               {

                    break;
                } // to stop print withdraw msg to winner
            }
        }
    }

    if (Winner == -1)
    {
        //printf("\nAuction end.");
        printf("\nThe property remains unowned.");
        printf("\n--------------- Auction End --------------------");
    }
    else
    {
        Square[PropertyID].Owner = Winner;
        Player[Winner].Cash -= CurrentBid - 250; // already increased current bid so need - 250

        switch (Square[PropertyID].GroupType)
        {
        case PROPERTY:
            Player[Winner].PropertiesOwned++;
            break;
        case RAILWAY:
            Player[Winner].RailwayStationsOwned++;
            break;
        case UTILITY:
            Player[Winner].UtilitiesOwned++;
            break;

        default:
            break;
        }
        printf("\n\n%s wins the auction for LKR %d\n", PLAYER_NAME[Player[Winner].PlayerID] , CurrentBid - 250);
        printf("\n--------------- Auction End --------------------");
    }
}