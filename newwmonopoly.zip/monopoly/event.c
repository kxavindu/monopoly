//-------------------------------------------------------------HANDLING SQUARES--------------------------------------------------------------
void HandleNationalEvent();
void HandleCommunityFund();